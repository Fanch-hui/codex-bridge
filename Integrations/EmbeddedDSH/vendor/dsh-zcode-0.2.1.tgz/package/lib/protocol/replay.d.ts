import type { AssistantMessage, ContentBlock, ReplayEnvelope } from '@deepseek-ai/dsh-llm';
import type { ProtocolContext } from './types.js';
export interface ReplayBlock {
    fingerprint: string;
    signature?: string;
}
export declare function fingerprint(block: ContentBlock): string;
export declare function replayEnvelope(context: ProtocolContext, blocks: ReplayBlock[], responseId?: string): ReplayEnvelope;
export declare function replayBlocks(message: AssistantMessage, context: ProtocolContext): (ReplayBlock | undefined)[];
