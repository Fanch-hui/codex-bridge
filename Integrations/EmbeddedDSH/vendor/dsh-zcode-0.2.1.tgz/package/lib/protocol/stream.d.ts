import type { StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ProtocolContext } from './types.js';
/** Translate Anthropic Messages SSE into DSH chunks with lossless native replay metadata. */
export declare function parseStream(body: ReadableStream<Uint8Array>, context: ProtocolContext, signal?: AbortSignal): AsyncGenerator<StreamChunk>;
