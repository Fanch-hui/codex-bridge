import { type GenerateOptions, type ImageAttachmentAccessResolver } from '@deepseek-ai/dsh-llm';
import type { ProtocolContext, ResolveImage, WireObject } from './types.js';
export declare function buildRequest(options: GenerateOptions<string>, context: ProtocolContext, image?: ResolveImage, access?: ImageAttachmentAccessResolver): Promise<WireObject>;
