import type { WireObject } from './types.js';
/** Decode UTF-8 incrementally and dispatch complete SSE data fields. */
export declare function readEvents(body: ReadableStream<Uint8Array>, signal?: AbortSignal): AsyncGenerator<WireObject>;
