import type { Plan, QuotaSnapshot } from '../types.js';
export declare function projectQuota(value: unknown, plan: Plan, now: number): QuotaSnapshot;
