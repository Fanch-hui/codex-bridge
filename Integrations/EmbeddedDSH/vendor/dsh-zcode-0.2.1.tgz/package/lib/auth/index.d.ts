import type { AccountSnapshot, AccountStatus, AuthPort, Plan, Platform, QuotaSnapshot, RequestCredential } from '../types.js';
import type { UpstreamPort } from '../proxy/types.js';
import { type CredentialStore } from './types.js';
export type { CredentialStore, KeyLocation, StoredAccount, StoredGrant } from './types.js';
export { AuthError } from './http.js';
export interface AuthOptions {
    store: CredentialStore;
    upstream: UpstreamPort;
    now?: () => number;
    onChange?: (status: AccountStatus) => void;
}
export declare class ZcodeAuth implements AuthPort {
    private readonly options;
    private readonly slots;
    private readonly now;
    private disposed;
    constructor(options: AuthOptions);
    private ensure;
    private changed;
    private serial;
    private settleAttempt;
    private cancelAttempt;
    private restoreCancelledLogin;
    private failedLoginState;
    private clearActive;
    private assertAttempt;
    private assertSnapshot;
    reconcile(platform: Platform): Promise<void>;
    status(platform: Platform, plan?: Plan): Promise<AccountStatus>;
    beginLogin(platform: Platform, signal?: AbortSignal): Promise<AccountStatus>;
    private finishLogin;
    waitForLogin(platform: Platform, attemptId: string, signal?: AbortSignal): Promise<void>;
    cancelLogin(platform: Platform): Promise<void>;
    useApiKey(platform: Platform, key: string): Promise<void>;
    disconnect(platform: Platform): Promise<void>;
    snapshot(platform: Platform, signal?: AbortSignal, plan?: Plan): Promise<AccountSnapshot>;
    credential(snapshot: AccountSnapshot, signal?: AbortSignal): Promise<RequestCredential>;
    private upstreamCredential;
    private checkPlanCredential;
    private migrateGrant;
    reject(snapshot: AccountSnapshot, credential: RequestCredential): void;
    queryQuota(snapshot: AccountSnapshot, signal?: AbortSignal, force?: boolean): Promise<QuotaSnapshot>;
    private applyQuotaState;
    markState(snapshot: AccountSnapshot, state: 'reauth_required' | 'quota_exhausted', errorCode: string): void;
    dispose(): void;
}
