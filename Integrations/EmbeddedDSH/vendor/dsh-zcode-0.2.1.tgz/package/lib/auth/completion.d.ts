import type { LoginAttempt, Platform } from '../types.js';
export declare function validateLogin(value: LoginAttempt, platform: Platform, now: number): LoginAttempt;
/** Retains a bounded, non-secret outcome for a single login attempt. */
export declare class LoginCompletion {
    private result?;
    private resolve;
    private readonly done;
    get finished(): boolean;
    settle(errorCode?: string): void;
    wait(signal: AbortSignal | undefined, committing: () => boolean): Promise<void>;
}
