import type { Platform } from '../types.js';
import type { UpstreamCredential } from '../proxy/types.js';
export interface KeyLocation {
    organizationId: string;
    projectId: string;
    apiKeyId: string;
}
export interface StoredGrant {
    kind: 'grant';
    payload: {
        schemaVersion: 1;
        platform: Platform;
        scope: string;
        oauthAccessToken?: string;
        zcodeToken?: string;
        upstream?: UpstreamCredential;
        accountLabel?: string;
        location?: KeyLocation;
    };
}
export interface StoredApiKey {
    kind: 'api-key';
    key: string;
    env: {
        DSH_ZCODE_SCOPE: string;
    };
}
export type StoredAccount = StoredGrant | StoredApiKey;
/** The store runs assertCurrent inside its exclusive write transaction. */
export interface CredentialStore {
    load(platform: Platform): Promise<StoredAccount | undefined>;
    save(platform: Platform, account: StoredAccount, assertCurrent: () => void, expected: StoredAccount | undefined): Promise<void>;
    remove(platform: Platform, assertCurrent: () => void, expected: StoredAccount | undefined): Promise<void>;
}
export declare function readAccount(value: unknown, platform: Platform): StoredAccount | undefined;
export declare function scopeOf(record: StoredAccount): string;
