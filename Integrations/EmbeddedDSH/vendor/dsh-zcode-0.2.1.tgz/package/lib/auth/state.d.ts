import type { AccountState, AccountStatus, LoginAttempt, Plan, Platform, QuotaSnapshot } from '../types.js';
import type { ProxyEngine, UpstreamCredential } from '../proxy/types.js';
import type { LoginCompletion } from './completion.js';
import { type StoredAccount } from './types.js';
export interface Attempt {
    id: string;
    platform: Platform;
    workerScope: string;
    controller: AbortController;
    engine: ProxyEngine;
    login?: LoginAttempt;
    workerId?: string;
    committing: boolean;
    committed?: string;
    cleanup?: () => void;
    completion: LoginCompletion;
    previousState: AccountState;
    previousError?: string;
}
export interface Slot {
    platform: Platform;
    generation: number;
    state: AccountState;
    errorCode?: string;
    record?: StoredAccount;
    load?: Promise<void>;
    loaded: boolean;
    controller: AbortController;
    revoked?: string;
    attempt?: Attempt;
    attempts: Map<string, Attempt>;
    write: Promise<void>;
    migration?: Promise<UpstreamCredential>;
    quotas: Map<Plan, {
        value?: QuotaSnapshot;
        pending?: Promise<QuotaSnapshot>;
    }>;
}
export declare function newSlot(platform: Platform): Slot;
export declare function identityOf(record: StoredAccount): string;
export declare function publicStatus(slot: Slot): AccountStatus;
