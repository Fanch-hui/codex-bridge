export declare class AuthError extends Error {
    readonly code: string;
    readonly status?: number | undefined;
    constructor(code: string, status?: number | undefined);
}
export declare function object(value: unknown): Record<string, unknown> | undefined;
export declare function string(value: unknown): string | undefined;
export declare function number(value: unknown): number | undefined;
export declare function waitFor<T>(promise: Promise<T>, signal?: AbortSignal): Promise<T>;
