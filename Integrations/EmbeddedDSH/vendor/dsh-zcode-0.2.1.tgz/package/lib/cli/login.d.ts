import type { AccountStatus, AuthPort, Platform } from '../types.js';
type LoginAuth = Pick<AuthPort, 'beginLogin' | 'waitForLogin'>;
/** Begin one OAuth attempt and wait until its own credential commit settles. */
export declare function login(auth: LoginAuth, platform: Platform, signal: AbortSignal, notify: (url: string) => void): Promise<void>;
export declare function accountState(account: AccountStatus): string;
export {};
