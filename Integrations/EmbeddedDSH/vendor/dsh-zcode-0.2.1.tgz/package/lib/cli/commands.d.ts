import type { AuthPort, Plan, Platform } from '../types.js';
type CliAction = 'login' | 'status' | 'quota' | 'disconnect' | 'help';
export interface CliArgs {
    action: CliAction;
    platform: Platform;
    plan?: Plan;
    home?: string;
}
export interface CliIO {
    out(value: string): void;
    error(value: string): void;
}
export interface CliEnvironment {
    auth: AuthPort;
    close(): Promise<void>;
}
export declare function parseArgs(args: readonly string[]): CliArgs;
export declare function runCli(args: readonly string[], io: CliIO, signal: AbortSignal, open: (home?: string) => Promise<CliEnvironment>): Promise<number>;
export {};
