import type { Context } from '@deepseek-ai/cordis';
import type { AuthPort } from '../types.js';
/** Expose the existing account owner to any DSH authorization surface. */
export declare function registerAuthorizationFlows(ctx: Context, auth: AuthPort): () => void;
