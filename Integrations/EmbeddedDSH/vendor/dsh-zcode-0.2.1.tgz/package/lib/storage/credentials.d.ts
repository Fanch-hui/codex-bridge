import { type CredentialProvider } from '@deepseek-ai/dsh-credentials';
import { type CredentialStore, type StoredAccount } from '../auth/index.js';
import type { Platform } from '../types.js';
/** Each platform has one active mode and a separate, typed manual-key record. */
export declare class DshCredentialStore implements CredentialStore {
    private readonly credentials;
    private readonly invalid;
    constructor(credentials: CredentialProvider);
    load(platform: Platform): Promise<StoredAccount | undefined>;
    save(platform: Platform, record: StoredAccount, assertCurrent: () => void, expected: StoredAccount | undefined): Promise<void>;
    remove(platform: Platform, assertCurrent: () => void, expected: StoredAccount | undefined): Promise<void>;
    private compare;
}
