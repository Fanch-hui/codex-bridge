export declare function createDeviceId(directory: string): () => Promise<string>;
