import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { AuthPort, AccountStatus, ModelRoute, Plan, Platform } from './types.js';
import type { Settings } from './config.js';
import type { ControlOperations, KeyInput, ZCodeStatus } from './control/types.js';
export declare class ZCodeRuntime implements ControlOperations {
    private readonly auth;
    private readonly settings;
    private readonly modelsUpdated;
    private readonly quotas;
    private readonly generations;
    private readonly usage;
    private disposed;
    constructor(auth: AuthPort, settings: () => Settings, modelsUpdated: (provider: string) => void);
    status(): Promise<ZCodeStatus>;
    recordUsage(route: ModelRoute, usage: TokenUsage): void;
    onAccountChanged(account: AccountStatus): void;
    beginLogin(platform: Platform): Promise<ZCodeStatus>;
    cancelLogin(platform: Platform): Promise<ZCodeStatus>;
    disconnect(platform: Platform): Promise<ZCodeStatus>;
    useApiKey(input: KeyInput): Promise<ZCodeStatus>;
    refreshModels(platform: Platform, plan?: Plan): Promise<ZCodeStatus>;
    readQuota(platform: Platform, plan?: Plan): Promise<ZCodeStatus>;
    refreshQuota(platform: Platform, plan?: Plan): Promise<ZCodeStatus>;
    dispose(): void;
    private loadQuota;
}
