import type { Volatile } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { Plan, Platform } from './types.js';
export interface Settings {
    platform: Platform;
    plan?: Plan;
    concurrency: number;
    maxTokens: number;
    timeoutMs: number;
    effort: 'low' | 'high' | 'max';
}
export interface Config {
    platform: Volatile<Platform>;
    plan: Volatile<Plan>;
    concurrency: Volatile<number>;
    maxTokens: Volatile<number>;
    timeoutMs: Volatile<number>;
    effort: Volatile<'low' | 'high' | 'max'>;
}
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    platform: z<"bigmodel" | "zai", "bigmodel" | "zai", "volatile-defined">;
    plan: z<"coding-plan" | "start-plan", "coding-plan" | "start-plan", "volatile-defined">;
    concurrency: z<number, number, "volatile-defined">;
    maxTokens: z<number, number, "volatile-defined">;
    timeoutMs: z<number, number, "volatile-defined">;
    effort: z<"low" | "high" | "max", "low" | "high" | "max", "volatile-defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    platform: z<"bigmodel" | "zai", "bigmodel" | "zai", "volatile-defined">;
    plan: z<"coding-plan" | "start-plan", "coding-plan" | "start-plan", "volatile-defined">;
    concurrency: z<number, number, "volatile-defined">;
    maxTokens: z<number, number, "volatile-defined">;
    timeoutMs: z<number, number, "volatile-defined">;
    effort: z<"low" | "high" | "max", "low" | "high" | "max", "volatile-defined">;
}>>, "plain">;
export declare function readSettings(config: Config): Settings;
