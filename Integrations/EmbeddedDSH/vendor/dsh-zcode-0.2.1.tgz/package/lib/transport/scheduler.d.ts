/** A round-robin queue per account; each admitted model attempt holds one slot. */
export declare class RequestScheduler {
    private readonly accounts;
    private disposed;
    acquire(account: string, session: string, limit: number, signal?: AbortSignal): Promise<() => void>;
    cooldown(account: string, delayMs: number): void;
    dispose(): void;
    private pump;
}
