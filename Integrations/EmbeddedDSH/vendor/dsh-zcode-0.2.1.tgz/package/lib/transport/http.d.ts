import { LlmError } from '@deepseek-ai/dsh-llm';
import type { AccountSnapshot, AuthPort, RequestCredential } from '../types.js';
export declare function retryAfter(response: Response, now?: number): number | undefined;
export declare function httpFailure(response: Response, account: AccountSnapshot, credential: RequestCredential, auth: Pick<AuthPort, 'reject' | 'markState'>, delay?: number): Promise<LlmError>;
