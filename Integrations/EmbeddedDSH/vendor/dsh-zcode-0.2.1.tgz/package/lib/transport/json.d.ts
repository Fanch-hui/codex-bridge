export declare function readBoundedJson(response: Response, maxBytes: number): Promise<unknown>;
