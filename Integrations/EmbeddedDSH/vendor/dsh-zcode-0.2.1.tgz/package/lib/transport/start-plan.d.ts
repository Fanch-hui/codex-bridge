import { LlmError } from '@deepseek-ai/dsh-llm';
export declare function startPlanBusinessFailure(value: unknown, status?: number): LlmError | undefined;
export declare function startPlanResponseFailure(response: Response): Promise<LlmError | undefined>;
