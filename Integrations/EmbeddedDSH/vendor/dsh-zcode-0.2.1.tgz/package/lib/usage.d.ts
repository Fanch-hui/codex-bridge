import type { TokenUsage } from '@deepseek-ai/dsh-llm';
import type { ModelRoute, UsageSnapshot } from './types.js';
/** Per-provider/model totals for calls made through this plugin. The overall sum is derived, never stored twice. */
export declare class TokenUsageTracker {
    private readonly models;
    record(route: ModelRoute, usage: TokenUsage): void;
    snapshot(): UsageSnapshot;
}
