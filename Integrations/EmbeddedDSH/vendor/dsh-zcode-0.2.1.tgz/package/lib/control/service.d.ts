import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { Plan, Platform } from '../types.js';
import type { ControlOperations, KeyInput } from './types.js';
export declare class ZCodeControl extends TypertRemoteService implements ControlOperations {
    private readonly operations;
    constructor(ctx: Context, operations: ControlOperations);
    status(): Promise<import("./types.js").ZCodeStatus>;
    beginLogin(platform: Platform): Promise<import("./types.js").ZCodeStatus>;
    cancelLogin(platform: Platform): Promise<import("./types.js").ZCodeStatus>;
    disconnect(platform: Platform): Promise<import("./types.js").ZCodeStatus>;
    useApiKey(input: KeyInput): Promise<import("./types.js").ZCodeStatus>;
    refreshModels(platform: Platform, plan?: Plan): Promise<import("./types.js").ZCodeStatus>;
    readQuota(platform: Platform, plan?: Plan): Promise<import("./types.js").ZCodeStatus>;
    refreshQuota(platform: Platform, plan?: Plan): Promise<import("./types.js").ZCodeStatus>;
}
