import { z } from 'zod';
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { TypertContribution } from '@deepseek-ai/dsh-typert-registry';
import type { ZCodeStatus } from './types.js';
export declare const REMOTE_PACKAGE = "dsh-zcode";
export declare const REMOTE_NAMESPACE = "zcode";
export declare const statusSchema: z.ZodType<ZCodeStatus>;
export declare const keyInputSchema: z.ZodObject<{
    platform: z.ZodEnum<{
        bigmodel: "bigmodel";
        zai: "zai";
    }>;
    key: z.ZodString;
}, z.core.$strict>;
export declare const remoteContribution: TypertRemoteContribution;
export declare const contribution: TypertRemoteContribution;
export declare const TYPERT: TypertContribution;
