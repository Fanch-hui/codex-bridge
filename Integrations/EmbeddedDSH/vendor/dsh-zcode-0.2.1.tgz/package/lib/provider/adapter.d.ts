import { LlmAdapter, type GenerateOptions, type StreamChunk, type PreparedAdapterCall, type TokenUsage } from '@deepseek-ai/dsh-llm';
import type { Settings } from '../config.js';
import type { AuthPort, ModelRoute } from '../types.js';
import { type ResolveImage } from '../protocol/index.js';
import { RequestScheduler } from '../transport/scheduler.js';
export interface AdapterDependencies {
    auth: AuthPort;
    settings(): Settings;
    fetch?: typeof fetch;
    image?: ResolveImage;
    sessionScope?: string;
    scheduler?: RequestScheduler;
    onUsage?: (route: ModelRoute, usage: TokenUsage) => void;
}
export declare class ZCodeAdapter extends LlmAdapter {
    private readonly dependencies;
    private readonly shutdown;
    private readonly series;
    private readonly scheduler;
    constructor(dependencies: AdapterDependencies);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    providerRetryPolicy(provider?: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    listModels(provider: string): Promise<import("@deepseek-ai/dsh-llm").LlmResolvedModelInfo[]>;
    resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<import("@deepseek-ai/dsh-llm").LlmResolvedModelInfo>;
    prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<PreparedAdapterCall>;
    stream(options: GenerateOptions): AsyncGenerator<StreamChunk>;
    dispose(): void;
    private bindAccount;
    private streamAccount;
}
