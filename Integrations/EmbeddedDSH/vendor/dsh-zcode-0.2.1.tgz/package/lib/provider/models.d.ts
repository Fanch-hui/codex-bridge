import type { Plan } from '../types.js';
export type ModelEffort = 'off' | 'low' | 'high' | 'max';
export interface ModelDefinition {
    id: string;
    contextWindow: number;
    maxTokens: number;
    image: boolean;
    efforts: readonly ModelEffort[];
    reasoning: 'required' | 'optional' | 'toggle';
}
export declare function modelsForPlan(plan: Plan): readonly string[];
export declare function modelDefinition(id: string): ModelDefinition;
