import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { AccountSnapshot } from '../types.js';
export declare function upstreamSession(scope: string, account: AccountSnapshot, options: GenerateOptions<string>): string;
