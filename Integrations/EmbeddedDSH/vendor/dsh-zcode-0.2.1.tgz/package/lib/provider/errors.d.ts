import { LlmError } from '@deepseek-ai/dsh-llm';
export declare function providerFailure(error: unknown): LlmError;
