import type { Plan, Platform } from '../types.js';
export declare const PROVIDER_DEFINITIONS: readonly [{
    readonly id: "zcode-bigmodel";
    readonly platform: "bigmodel";
    readonly plan: "coding-plan";
    readonly name: "ZCode · 智谱 Coding Plan";
}, {
    readonly id: "zcode-zai";
    readonly platform: "zai";
    readonly plan: "coding-plan";
    readonly name: "ZCode · Z.AI Coding Plan";
}, {
    readonly id: "zcode-bigmodel-start-plan";
    readonly platform: "bigmodel";
    readonly plan: "start-plan";
    readonly name: "ZCode · 智谱 Start Plan";
}, {
    readonly id: "zcode-zai-start-plan";
    readonly platform: "zai";
    readonly plan: "start-plan";
    readonly name: "ZCode · Z.AI Start Plan";
}];
export declare function providerFor(platform: Platform, plan?: Plan): string;
