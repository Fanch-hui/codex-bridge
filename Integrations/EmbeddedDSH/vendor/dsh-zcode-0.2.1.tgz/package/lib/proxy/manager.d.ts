import type { Platform } from '../types.js';
import type { ProxyEngine, UpstreamPort } from './types.js';
interface ManagerOptions {
    deviceId(): Promise<string>;
    workerUrl?: URL;
}
/** Each account/plan owns its process and the upstream module's caches. */
export declare class UpstreamManager implements UpstreamPort {
    private readonly options;
    private readonly engines;
    private disposed;
    constructor(options: ManagerOptions);
    get(platform: Platform, scope?: string): ProxyEngine;
    invalidate(platform: Platform): void;
    release(platform: Platform, scope: string): void;
    dispose(): void;
}
export {};
