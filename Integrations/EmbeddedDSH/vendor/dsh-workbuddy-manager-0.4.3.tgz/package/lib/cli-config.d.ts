export interface CliOptions {
    baseURL: string;
    gatewayKey?: string;
    apiToken?: string;
    timeoutMs: number;
    json: boolean;
}
export interface CliInvocation {
    command: string;
    options: CliOptions;
    help: boolean;
}
export declare const COMMANDS: readonly ["doctor", "status", "models", "usage", "me", "accounts", "credits"];
export declare class CliError extends Error {
    constructor(message: string);
}
/** Connection settings come from one place: the environment, overridden by flags. */
export declare function parseArgs(argv: string[], env?: NodeJS.ProcessEnv): CliInvocation;
export declare const HELP_TEXT = "dsh-workbuddy \u2014 WorkBuddy Manager \u53EA\u8BFB\u8FD0\u7EF4\u5DE5\u5177\n\n\u7528\u6CD5:\n  dsh-workbuddy <\u547D\u4EE4> [--url <\u5730\u5740>] [--gateway-key <wbk_...>]\n                [--api-token <wbt_...>] [--timeout <\u6BEB\u79D2>] [--json]\n\n\u547D\u4EE4:\n  doctor     \u9010\u9879\u68C0\u67E5\u670D\u52A1\u5B58\u6D3B\u3001\u7F51\u5173\u5BC6\u94A5\u3001\u989D\u5EA6\u81EA\u67E5\u4E0E\u53EA\u8BFB\u4EE4\u724C\n  status     \u805A\u5408 healthz / models / usage \u7684\u72B6\u6001\u5FEB\u7167\n  models     GET /v1/models           \uFF08\u7F51\u5173\u5BC6\u94A5\uFF09\n  usage      GET /v1/usage            \uFF08\u7F51\u5173\u5BC6\u94A5\uFF09\n  me         GET /api/me              \uFF08\u53EA\u8BFB\u4EE4\u724C\uFF09\n  accounts   GET /api/accounts        \uFF08\u53EA\u8BFB\u4EE4\u724C\uFF09\n  credits    GET /api/accounts/credits-snapshot\uFF08\u53EA\u8BFB\u4EE4\u724C\uFF09\n\n\u73AF\u5883\u53D8\u91CF\uFF08\u547D\u4EE4\u884C\u53C2\u6570\u4F18\u5148\uFF09:\n  WORKBUDDY_MANAGER_URL              \u670D\u52A1\u6839\u5730\u5740\uFF0C\u9ED8\u8BA4 http://127.0.0.1:7864\n  WORKBUDDY_MANAGER_API_KEY          \u7F51\u5173\u5BC6\u94A5 wbk_...\uFF0C\u4E0E DSH \u7684 apiKeyEnv \u540C\u540D\n  WORKBUDDY_MANAGER_READONLY_TOKEN   \u7BA1\u7406\u9762\u53EA\u8BFB\u4EE4\u724C wbt_...\n  WORKBUDDY_MANAGER_TIMEOUT_MS       \u5355\u6B21\u8BF7\u6C42\u8D85\u65F6\uFF0C\u9ED8\u8BA4 10000\n\n\u8BF4\u660E:\n  \u672C\u5DE5\u5177\u53EA\u8BFB\uFF0C\u4E0D\u505A\u626B\u7801\u7EB3\u7BA1\u3001\u7B7E\u5230\u3001\u8D26\u53F7\u589E\u5220\u6216\u5BC6\u94A5\u7BA1\u7406\u3002\n  \u4EC5\u7528\u4E8E\u7BA1\u7406\u672C\u4EBA\u53CA\u4EB2\u5C5E\u81EA\u613F\u6388\u6743\u7684\u8D26\u53F7\uFF1B\u7981\u6B62\u6279\u91CF\u6CE8\u518C\u3001\u8D26\u53F7\u4EA4\u6613\u3001\n  \u7ED5\u8FC7\u5E73\u53F0\u98CE\u63A7\u4EE5\u53CA\u4EFB\u4F55\u5546\u4E1A\u8F6C\u552E\u7528\u9014\u3002\u5BC6\u94A5\u4E0D\u4F1A\u5199\u5165\u65E5\u5FD7\u6216\u8F93\u51FA\u3002\n";
