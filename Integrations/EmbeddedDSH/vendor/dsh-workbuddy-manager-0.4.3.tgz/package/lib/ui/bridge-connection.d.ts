import type { ManagerRequest } from '../manager/contract.js';
import { type Remote } from './connection.js';
export interface BridgeRemote extends Remote {
    workbuddy: {
        manage(request: ManagerRequest): Promise<{
            ok: true;
            value: unknown;
        } | {
            ok: false;
            error: {
                message: string;
            };
        }>;
    };
}
/** Connects the in-host local gateway provider to llm-pi-ai without touching other providers. */
export declare function connectBridge(remote: BridgeRemote, active?: () => boolean): Promise<number | undefined>;
