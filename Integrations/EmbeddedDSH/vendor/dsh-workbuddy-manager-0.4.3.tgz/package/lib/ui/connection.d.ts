export { normalizeURL, managementURL } from '../address.js';
export declare const PROVIDER = "workbuddy-manager";
export declare const CREDENTIAL_REF = "WORKBUDDY_MANAGER_API_KEY";
export declare const DEFAULT_URL = "http://127.0.0.1:7864/v1";
type Dictionary = Record<string, unknown>;
type RemoteResult<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: {
        code?: string;
        message: string;
    };
};
interface NamespaceView {
    ns: string;
    value: Dictionary;
    revision: unknown;
}
export interface Model {
    id: string;
    name?: string;
    contextWindow?: number;
    maxTokens?: number;
    input?: string[];
}
export interface Remote {
    settings: {
        describe(): Promise<RemoteResult<{
            writable: boolean;
            namespaces: NamespaceView[];
        }>>;
        mutate(ns: string, operations: Array<{
            op: 'set';
            path: string[];
            value: unknown;
        }>, revision: unknown): Promise<RemoteResult<NamespaceView>>;
    };
    credentials: {
        describe(refs: string[]): Promise<RemoteResult<Record<string, {
            configured: boolean;
            writable: boolean;
        }>>>;
        set(ref: string, value: string): Promise<RemoteResult<unknown>>;
        unset(ref: string): Promise<RemoteResult<unknown>>;
    };
    llm: {
        discoverModels(ns: string, request: {
            provider?: string;
            baseURL: string;
            api: string;
            apiKey?: string;
        }): Promise<RemoteResult<Array<{
            id: string;
            name?: string;
            contextWindow?: number;
            maxTokens?: number;
            inputModalities?: string[];
        }>>>;
    };
}
export interface Connection {
    providerId: string;
    candidates: Array<{
        id: string;
        label: string;
    }>;
    url: string;
    api: 'openai-completions' | 'openai-responses';
    keyRef: string;
    keyConfigured: boolean;
    keyWritable: boolean;
    writable: boolean;
    existing: boolean;
    hasUnsupportedCompat?: boolean;
    models: Model[];
    revision: unknown;
}
export declare function loadConnection(remote: Remote, selectedId?: string): Promise<Connection>;
/** Ask the host's official pi-ai discovery endpoint; a typed key is one-shot. */
export declare function discover(remote: Remote, connection: Connection, address: string, key: string): Promise<Model[]>;
/** Preserve existing model settings; backfill newly advertised capabilities and append new models. */
export declare function mergeModels(current: Model[], discovered: Model[]): Model[];
/** Bind a separately stored key without changing any other credential reference. */
export declare function attachCredential(remote: Remote, connection: Connection, address: string, ref: string, seedModels?: Model[]): Promise<Connection>;
export declare function newCredentialRef(): string;
/** Update only this provider's fields, with the revision captured at load time. */
export declare function sync(remote: Remote, connection: Connection, address: string, key: string): Promise<number>;
/** Remove a credential written for a change that did not take effect; report a failed cleanup to the user. */
export declare function discardUnusedCredential(remote: Remote, ref: string): Promise<string>;
export declare function safeMessage(error: unknown, key: string): string;
