import { TYPERT_REMOTE } from '../manager/contract.js';
import { WorkbuddyPanel } from './panel.js';
import type { AppRemote } from './management.js';
export declare const inject: string[];
interface ClientContext {
    remote: AppRemote & {
        $mount(contribution: typeof TYPERT_REMOTE): Promise<() => Promise<void>>;
    };
    slots: {
        inject(name: string, register: () => unknown): void;
        register(options: {
            name: string;
            id: string;
            order: number;
            label: () => string;
            inject: () => {
                remote: AppRemote;
            };
        }, component: typeof WorkbuddyPanel): unknown;
    };
    inject(names: string[], register: (context: ClientContext) => void): PromiseLike<void> & {
        dispose(): Promise<void>;
    };
}
export declare function apply(ctx: ClientContext): Promise<() => Promise<void>>;
export {};
