import { type Connection } from './connection.js';
import { type AppRemote } from './management.js';
export declare function targetURL(_connection: Connection, address: string): string;
interface Props {
    remote: AppRemote;
}
export declare function WorkbuddyPanel({ remote }: Props): import("react").JSX.Element;
export {};
