import type { ManagerRequest } from '../manager/contract.js';
import { type Remote } from './connection.js';
type Result<T> = {
    ok: true;
    value: T;
} | {
    ok: false;
    error: {
        message: string;
    };
};
export interface AppRemote extends Remote {
    workbuddy: {
        manage(request: ManagerRequest): Promise<Result<unknown>>;
    };
}
interface Account {
    file: string;
    nickname: string;
    note: string;
    realm: string;
    source?: string;
    disabled: boolean;
    blocked: boolean;
    expired: boolean;
    inPool: boolean;
    cooling: boolean;
    coolingModels?: string[];
    credits: number | null;
    creditsUpdatedAt?: number;
    creditsError?: string;
    cycleEnd?: string;
    runsOutAt?: string;
}
interface Props {
    remote: AppRemote;
    writable: boolean;
    disabled: boolean;
    onBusyChange: (busy: boolean) => void;
    onConnect: (active: () => boolean) => Promise<boolean>;
}
export declare function accountStatus(account: Account, poolAvailable: boolean): string;
export declare function keyScope(realm: string): string;
export declare function copyLoginLink(url: string, clipboard: Pick<Clipboard, 'writeText'> | undefined): Promise<boolean>;
export declare function Management({ remote, writable, disabled, onBusyChange, onConnect }: Props): import("react").JSX.Element;
export {};
