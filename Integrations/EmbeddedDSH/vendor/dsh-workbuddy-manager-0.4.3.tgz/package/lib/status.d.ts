import type { WorkbuddyManagerClient } from './client.js';
export interface SnapshotPart {
    ok: boolean;
    data?: unknown;
    error?: string;
}
/** One failing endpoint must not hide the rest of the snapshot. */
export declare function snapshot(client: WorkbuddyManagerClient): Promise<Record<string, SnapshotPart>>;
