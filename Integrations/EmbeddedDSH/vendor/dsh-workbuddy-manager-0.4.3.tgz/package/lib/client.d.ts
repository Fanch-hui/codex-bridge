import type { CliOptions } from './cli-config.js';
export declare class WorkbuddyError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
export type AuthKind = 'gateway' | 'api' | 'none';
type ClientOptions = Pick<CliOptions, 'baseURL' | 'gatewayKey' | 'apiToken' | 'timeoutMs'>;
/** Read-only HTTP client for a deployed WorkBuddy Manager instance. */
export declare class WorkbuddyManagerClient {
    private readonly options;
    constructor(options: ClientOptions);
    health(): Promise<unknown>;
    models(): Promise<unknown>;
    usage(): Promise<unknown>;
    me(): Promise<unknown>;
    accounts(): Promise<unknown>;
    credits(): Promise<unknown>;
    private get;
    private tokenFor;
}
export {};
