import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { AccountPoolStore } from '../gateway/pool-store.js';
import { LocalGatewayServer } from '../gateway/server.js';
import { type Realm, type SiteConfig } from '../gateway/sites.js';
import { type ManagerRequest } from './contract.js';
export interface ManagerOptions {
    sites?: Partial<Record<Realm, Partial<SiteConfig>>>;
}
/** Manages the in-host WorkBuddy account pool and local gateway, restricted to the DSH owner. */
export declare class ManagerRemote extends TypertRemoteService {
    readonly pool: AccountPoolStore;
    readonly gateway: LocalGatewayServer;
    private readonly sites;
    private pending?;
    private operation;
    constructor(ctx: Context, options?: ManagerOptions);
    private bootstrapGateway;
    private isGatewayRequest;
    manage(input: ManagerRequest): Promise<unknown>;
    private serialized;
    private dispatch;
    ensureGateway(): Promise<string>;
    private health;
    private overview;
    private issueBridge;
    private authStart;
    private authPoll;
    private authDesktop;
    private authKey;
    private accountDisabled;
    private accountDelete;
    private accountRefresh;
    private accountCheckin;
    private updateGatewayOptions;
}
