import { z } from 'zod';
export declare const managerRequest: z.ZodDiscriminatedUnion<[z.ZodObject<{
    action: z.ZodLiteral<"health">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"overview">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"bridge">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"authStart">;
    realm: z.ZodEnum<{
        cn: "cn";
        global: "global";
    }>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"authPoll">;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"authDesktop">;
    realm: z.ZodEnum<{
        cn: "cn";
        global: "global";
    }>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"authKey">;
    realm: z.ZodEnum<{
        cn: "cn";
        global: "global";
    }>;
    key: z.ZodString;
    nickname: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"accountDisabled">;
    file: z.ZodString;
    disabled: z.ZodBoolean;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"accountDelete">;
    file: z.ZodString;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"accountRefresh">;
    file: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"accountCheckin">;
    file: z.ZodOptional<z.ZodString>;
}, z.core.$strip>, z.ZodObject<{
    action: z.ZodLiteral<"gatewayOptions">;
    freeOnly: z.ZodOptional<z.ZodBoolean>;
    hideDsh: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strip>], "action">;
export type ManagerRequest = z.infer<typeof managerRequest>;
/** This explicit descriptor is shared by the host registry and browser Remote. */
export declare const TYPERT_REMOTE: import("@deepseek-ai/dsh-typert-protocol").TypertRemoteInfo<Readonly<Record<string, import("@deepseek-ai/dsh-typert-protocol").TypertRemoteMethod<object, unknown, "unary", never, unknown> | import("@deepseek-ai/dsh-typert-protocol").TypertRemoteMethod<object, unknown, "stream", unknown, unknown>>>>;
export declare const TYPERT: {
    package: string;
    face: string;
    schemas: never[];
    readonly invocations: readonly import("@deepseek-ai/dsh-typert-protocol").InvocationDescriptor[];
    model: {
        services: {
            key: string;
            exportName: string;
            tags: never[];
            members: never[];
            types: never[];
        }[];
        events: never[];
        objects: never[];
    };
};
