import { type AccountIdentity } from './sites.js';
export declare const SESSION = "x-magpie-workbuddy-session";
export interface AttendedIds {
    set: string[];
    turn: string;
    conv: string;
}
export declare function idFor(kind: string, key: string | string[]): string;
export declare function signatureParts(content: unknown): string[];
export declare function signatureOf(content: unknown): string;
export declare function answeredBefore(msgs: any[], i: number): boolean;
export declare function turnParts(chat: any): string[];
export declare function turnKey(chat: any): string;
export declare function conversationParts(chat: any, session?: string): string[];
export declare function conversationKey(chat: any, session?: string): string;
export declare function sessionOf(headers: Headers): string;
export declare function scopeOf(a?: AccountIdentity): string;
export declare function attendChat(headers: Headers, chat: any, session?: string, who?: string): AttendedIds;
export declare function reattend(headers: Headers, ids: AttendedIds, was: string, now: string): AttendedIds;
