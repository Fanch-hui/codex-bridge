import { type AccountIdentity, type SiteConfig } from './sites.js';
export declare const EDGE_READS: number;
export declare const edgeNotes: WeakMap<Response, string>;
export declare function meterAsked(site: SiteConfig, a: AccountIdentity, path: string, body?: Record<string, unknown>, signal?: AbortSignal): Promise<Response>;
export declare function unanswered(site: SiteConfig, a: AccountIdentity, body: unknown, err: any, signal?: AbortSignal | null): Promise<Response>;
export declare function meter(site: SiteConfig, a: AccountIdentity, path: string, body?: Record<string, unknown>): Promise<any>;
export declare function capacity(v: unknown): number;
export declare function kindsOf(sum: any, site: SiteConfig): {
    plan: {
        total: number;
        used: number;
    };
    extra: {
        total: number;
        used: number;
    };
    left: number;
    bags: number;
};
export declare function listedExtra(sum: any, packages: any[], site: SiteConfig, now?: number): {
    total: number;
    used: number;
    runsOutAt?: string;
} | null;
export declare function cycleOf(sum: any, packages: any[], now?: number): {
    resetsAt: string;
    span?: number;
} | null;
export declare function runsOutOf(sum: any, packages: any[], now?: number): {
    runsOutAt: string;
    runsOut: number;
} | null;
export interface UsageLookupOptions {
    getAccount?: () => Promise<AccountIdentity | null | undefined>;
    saveAccount?: (next: AccountIdentity) => Promise<void> | void;
}
export interface AccountUsageResult {
    credits: number | null;
    cycleEnd?: string;
    runsOutAt?: string;
    error?: string;
    signIn: 'kept' | 'renewed' | 'expired';
    updatedAccount?: AccountIdentity;
}
export declare function fetchAccountUsage(site: SiteConfig, initial: AccountIdentity, options?: UsageLookupOptions): Promise<AccountUsageResult>;
export declare function fetchAccountCredits(site: SiteConfig, a: AccountIdentity, options?: UsageLookupOptions): Promise<number | null>;
export declare function checkinOf(site: SiteConfig, a: AccountIdentity, { waits }?: {
    waits?: number[];
}): Promise<{
    outcome: 'claimed' | 'done' | 'inactive' | 'ineligible' | 'failed';
    credit?: number;
    streak?: number;
    message?: string;
}>;
