export type Realm = 'cn' | 'global';
export type ModelTuple = readonly [string, string, number, (readonly string[])?];
export interface SiteConfig {
    id: string;
    realm: Realm;
    name: string;
    endpoint: string;
    authID: string;
    platform: string;
    ai: boolean;
    app: string;
    cli: string;
    appName: string;
    runtime: string;
    keys: string;
    models: ReadonlyArray<ModelTuple>;
    noImages?: RegExp;
    messages?: boolean;
}
export interface ModelSpec {
    id: string;
    name: string;
    context?: number;
    output?: number;
    images?: boolean;
    free?: boolean;
    rate?: number;
    rateWas?: number;
    efforts?: string[];
    effort?: string;
    native?: boolean;
}
export interface AccountIdentity {
    access: string;
    refresh?: string;
    expires?: number;
    refreshExpiresAt?: number;
    uid?: string;
    domain?: string;
    enterpriseId?: string;
    enterpriseName?: string;
    tokenType?: string;
    source?: 'browser' | 'desktop' | 'key' | string;
    key?: string;
}
export declare const CN_MODELS: ReadonlyArray<ModelTuple>;
export declare const AI_MODELS: ReadonlyArray<ModelTuple>;
export declare const SITES: Record<Realm, SiteConfig>;
export declare const OFF_TAKEN: Set<string>;
export declare const hex: () => string;
export declare const textOnly: (site: SiteConfig, model: string) => boolean;
export declare const nativeOf: (site: SiteConfig | undefined, model: unknown) => boolean;
export declare const remoteConfig: (key?: string) => boolean;
export declare const domainOf: (site: SiteConfig, a: AccountIdentity) => string;
export declare function enterpriseHeaders(a?: AccountIdentity): Record<string, string>;
export declare function cliAgent(site: SiteConfig): string;
export declare function sign(site: SiteConfig, a: AccountIdentity, headers: Headers): void;
export declare function chatHeaders(site: SiteConfig, headers: Headers): void;
export declare function creditsOf(c: unknown): number | undefined;
export declare const freeCredits: (c: unknown) => boolean;
export declare function priceOf(d: Record<string, any>, promotions?: any[], now?: number): {
    free?: boolean;
    rate?: number;
    rateWas?: number;
};
export declare function notFree(site: SiteConfig, model?: string, why?: string): Response;
export declare function fallbackModels(site: SiteConfig): ModelSpec[];
export declare function defaultEffortOf(d: Record<string, any>, efforts: string[]): string | undefined;
export declare function liveModels(site: SiteConfig, a: AccountIdentity): Promise<ModelSpec[]>;
