import type { AccountPoolStore } from './pool-store.js';
import { type ModelSpec, type Realm, type SiteConfig } from './sites.js';
export interface GatewayOptions {
    pool: AccountPoolStore;
    sites?: Record<Realm, SiteConfig>;
}
export declare class LocalGatewayServer {
    private readonly options;
    readonly token: string;
    private server?;
    private port;
    private starting?;
    private readonly sites;
    private readonly modelCache;
    private readonly unlisted;
    private readonly realmModels;
    private readonly refusedSystems;
    private readonly commaSystems;
    private readonly endsAfterTools;
    private readonly activeRequests;
    constructor(options: GatewayOptions);
    get baseURL(): string;
    get listeningPort(): number;
    ensureStarted(preferredPort?: number): Promise<string>;
    private listen;
    close(): Promise<void>;
    private checkAuth;
    private handleRequest;
    private listKey;
    private modelsForAccount;
    private effortList;
    discoverModels(): Promise<ModelSpec[]>;
    private routingScopeForModel;
    private ensureFresh;
    private handleModelRequest;
    private sendWithAccount;
    private retryRefused;
    private classifyFailure;
    private pipeResponse;
}
