import { type AccountIdentity, type Realm, type SiteConfig } from './sites.js';
export declare class WBError extends Error {
    readonly code?: number | string | undefined;
    readonly status?: number | undefined;
    readonly said?: string | undefined;
    constructor(message: string, code?: number | string | undefined, status?: number | undefined, said?: string | undefined);
}
export interface PendingAuth {
    realm: Realm;
    state: string;
    authUrl: string;
    createdAt: number;
    token?: AccountIdentity;
}
export interface SignedInAccount extends AccountIdentity {
    realm: Realm;
    uid: string;
    nickname: string;
    enterpriseId?: string;
    enterpriseName?: string;
}
export type ReissueOutcome = {
    a: AccountIdentity;
    why?: undefined;
    kind?: undefined;
} | {
    a?: undefined;
    why: string;
    kind: 'refresh refused' | 'nothing to renew with' | 'unknown';
};
export declare function call(site: SiteConfig, method: string, path: string, headers?: Record<string, string>, body?: unknown): Promise<any>;
export declare function mergeToken(a: AccountIdentity, got: Record<string, any>): AccountIdentity;
export declare const stale: (a: AccountIdentity) => boolean;
export declare const refreshable: (a: AccountIdentity) => boolean;
export declare const invalidToken: (res?: Response | null) => boolean;
export declare const refreshRefused: (e: unknown) => boolean;
export declare const desktopHeld: Map<string, AccountIdentity>;
export declare function desktopFile(site: SiteConfig): string;
export declare function readDesktop(site: SiteConfig): (AccountIdentity & {
    uid: string;
    name: string;
    source: 'desktop';
}) | null;
export declare function notDesktop(site: SiteConfig): string;
export declare function keyAccount(rawKey: string, realm: Realm, nickname?: string): SignedInAccount | null;
export declare function renew(site: SiteConfig, a: AccountIdentity, save?: (next: AccountIdentity) => Promise<void> | void): Promise<AccountIdentity>;
export declare function fresh(site: SiteConfig, a: AccountIdentity, save?: (next: AccountIdentity) => Promise<void> | void): Promise<AccountIdentity>;
export declare function reissued(site: SiteConfig, getAccount: () => Promise<AccountIdentity | null | undefined>, saveAccount: ((next: AccountIdentity) => Promise<void> | void) | undefined, a: AccountIdentity, began?: string): Promise<ReissueOutcome>;
export declare const gone: (a: AccountIdentity, r: {
    kind?: string;
}, tokenRefused: boolean) => boolean;
export declare function refusedText(site: SiteConfig, a: AccountIdentity, why?: string, note?: string): string;
export declare function keyRefused(site: SiteConfig, expired: boolean, note?: string): Response;
export declare function signedOut(site: SiteConfig, a: AccountIdentity, why: string, expired: boolean, note?: string): Response;
export declare function kept(res: Response, said?: 'kept' | 'renewed'): Response;
export declare function enterpriseOf(site: SiteConfig, a: AccountIdentity, who: Record<string, any>): Promise<{
    id: string;
    name: string;
}>;
export declare function accountName(who: Record<string, any>, ent?: {
    id?: string;
    name?: string;
}): string;
export declare function startBrowserAuth(site: SiteConfig): Promise<PendingAuth>;
export declare function pollBrowserAuthStep(site: SiteConfig, pending: PendingAuth): Promise<{
    status: 'pending' | 'scanned' | 'success' | 'expired';
    account?: SignedInAccount;
    error?: string;
}>;
export { checkinOf, edgeNotes, fetchAccountCredits, fetchAccountUsage, unanswered } from './billing.js';
