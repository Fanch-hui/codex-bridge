export declare const FILTER_SAYS: string[];
export declare const REFUSED_DOC = "https://github.com/magpie-community/plugins/blob/main/packages/workbuddy/REFUSED.md";
export declare const REFUSED_HINT = "WorkBuddy refused words in this client's prompt (most often its system prompt); use it from Hermes, OpenCode or Pi, or add another provider to this group";
export declare const RESTRICTED_HINT = "WorkBuddy restricted this account for unusual activity; it stays out until WorkBuddy lifts that, which an appeal (Submit feedback in WorkBuddy) asks for";
export declare const RESTRICTED_CODE = 11140;
export declare const RESTRICTED_TEXT: RegExp;
export declare const EXHAUSTED_HINT = "WorkBuddy requires an active credit package even for 0-rate free models; check your account package balance";
export declare const EXHAUSTED_TEXT: RegExp;
export declare const MODEL_RATE_LIMIT_TEXT: RegExp;
export declare const isModelRateLimit: (text: string) => boolean;
export declare function namedBack(v: any, names: Map<string, string>): boolean;
export declare function renamed(res: Response, names: Map<string, string>): Promise<Response>;
export declare function unsaid(res: Response): Response;
export declare function inspectStreamForFailover(res: Response): Promise<{
    response: Response;
    filterRefused: boolean;
    streamErrorText?: string;
}>;
export declare function windowOffset(text: unknown): number | null;
export declare function windowReset(text: unknown): number;
export declare function classifyUpstreamError(text: string): {
    isRefused: boolean;
    isRestricted: boolean;
    isExhausted: boolean;
    isModelRateLimit: boolean;
    codes: number[];
    message: string;
};
export declare function explained(res: Response, preReadText?: string): Promise<Response>;
