import type { AccountIdentity, Realm } from './sites.js';
import type { SignedInAccount } from './oauth.js';
export interface PoolAccount extends AccountIdentity {
    id: string;
    realm: Realm;
    uid: string;
    nickname: string;
    note?: string;
    disabled: boolean;
    expired?: boolean;
    restricted?: boolean;
    coolingUntil?: number;
    modelCooling?: Record<string, number>;
    credits?: number | null;
    creditsUpdatedAt?: number;
    creditsError?: string;
    cycleEnd?: string;
    runsOutAt?: string;
}
export interface AccountItem {
    file: string;
    nickname: string;
    note: string;
    realm: Realm;
    source?: string;
    disabled: boolean;
    blocked: boolean;
    expired: boolean;
    inPool: boolean;
    cooling: boolean;
    coolingModels?: string[];
    credits: number | null;
    creditsUpdatedAt?: number;
    creditsError?: string;
    cycleEnd?: string;
    runsOutAt?: string;
}
export interface GatewaySwitchOptions {
    freeOnly: boolean;
    hideDsh: boolean;
}
export interface SelectCandidatesOptions {
    preferredRealm?: Realm;
    allowedRealms?: ReadonlySet<Realm>;
    model?: string;
    advanceCursor?: boolean;
}
export interface CredentialStoreLike {
    readRecord?(key: string): Promise<unknown>;
    modifyRecord?(key: string, mutate: (current: unknown) => Promise<unknown> | unknown): Promise<unknown>;
    deleteRecord?(key: string): Promise<void>;
    describe?(refs: string[]): Promise<Record<string, {
        configured: boolean;
        writable: boolean;
    }> | {
        configured: boolean;
        writable: boolean;
    }>;
    set?(ref: string, value: string): Promise<void>;
    unset?(ref: string): Promise<void>;
    resolve?(ref: string): Promise<{
        value: string;
    } | undefined>;
}
export declare function sharedWindowModels(model: string): string[];
export declare function isModelCooled(account: PoolAccount, model?: string, now?: number): boolean;
export declare function accountIdOf(realm: Realm, uid: string, enterpriseId?: string): string;
export declare function toAccountItem(account: PoolAccount, now?: number): AccountItem;
export declare class AccountPoolStore {
    private readonly credentials;
    private memory;
    private queue;
    private cursor;
    private readonly inFlight;
    constructor(credentials: () => CredentialStoreLike | undefined);
    private runExclusive;
    private readState;
    private updateState;
    listAccounts(): Promise<PoolAccount[]>;
    getAccount(id: string): Promise<PoolAccount | undefined>;
    listAccountItems(): Promise<AccountItem[]>;
    upsertSignedIn(signedIn: SignedInAccount, credits?: number | null, extra?: Partial<PoolAccount>): Promise<PoolAccount>;
    updateAccount(id: string, patch: Partial<PoolAccount>): Promise<PoolAccount | undefined>;
    coolModel(id: string, model: string, coolingUntil: number): Promise<PoolAccount | undefined>;
    removeAccount(id: string): Promise<boolean>;
    gatewayMeta(): Promise<{
        port?: number;
        keyRef?: string;
    }>;
    saveGatewayMeta(port: number, keyRef: string): Promise<void>;
    getGatewayOptions(): Promise<GatewaySwitchOptions>;
    saveGatewayOptions(patch: Partial<GatewaySwitchOptions>): Promise<GatewaySwitchOptions>;
    acquireInFlight(id: string): void;
    releaseInFlight(id: string): void;
    inFlightCount(id: string): number;
    selectCandidates(input?: Realm | SelectCandidatesOptions): Promise<PoolAccount[]>;
}
