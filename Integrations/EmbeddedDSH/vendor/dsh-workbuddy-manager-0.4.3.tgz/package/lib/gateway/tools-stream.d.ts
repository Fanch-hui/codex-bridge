export declare function fitSchema(s: any, depth?: number): boolean;
export declare function fitShape(s: any, depth?: number): boolean;
export declare function typeUnions(s: any, root?: any, depth?: number): boolean;
export declare function objectRoot(ps: any, root?: any, depth?: number): boolean;
export declare function fitTools(b: any): {
    changed: boolean;
    names: Map<string, string>;
};
export declare function toolChoiceOn(b: any): boolean;
export declare function prepared(body: string, native?: boolean): {
    body: string;
    chat: Record<string, any> | null;
    names: Map<string, string>;
    changed: boolean;
};
