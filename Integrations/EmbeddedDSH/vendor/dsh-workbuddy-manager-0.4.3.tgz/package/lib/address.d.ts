/** URLs never carry credentials; plaintext is restricted to the local machine. */
export declare function normalizeURL(input: string): string;
export declare function managementURL(input: string): string;
export declare const BRIDGE_PROVIDER = "workbuddy-manager-session";
export declare const BRIDGE_CREDENTIAL_REF = "WORKBUDDY_MANAGER_BRIDGE_8F4D2C1E9A0B7E6D5C3A1F2E4B6D8C0A";
