import { WorkbuddyManagerClient } from './client.js';
import type { CliOptions } from './cli-config.js';
export interface CheckResult {
    name: string;
    ok: boolean;
    detail: string;
}
/** Diagnose the deployment without writing anything to it. */
export declare function runDoctor(client: WorkbuddyManagerClient, options: CliOptions): Promise<CheckResult[]>;
